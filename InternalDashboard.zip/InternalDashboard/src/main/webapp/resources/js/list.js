function selectOption() 
{
	var flag=0;
	
	
	if (document.getElementById("program").value == "MM") 
	{
		
		document.getElementById("userlist").style.display = "block";
		var apiurl = "/userDetailsListMM";
		
	}
	else if (document.getElementById("program").value == "NIUM") {
		
		
		document.getElementById("userlist").style.display = "block";
		var apiurl = "/userDetailsListNIUM";
		
		
	}
	else if (document.getElementById("program").value == "SP") {
		document.getElementById("userlist").style.display = "none";

	}
	else {
	}
	$.ajax({
		method: "GET",
		url: apiurl,
		timeout: 100000,
		success: function(data) {


			var obj = JSON.parse(data);

			var table = $('#myUserTable');
			$('#myUserTable').empty()
			for (var i = 0; i < obj.length; i++) {

				var val = obj[i];


				var table = '<tr><td>' + i + "\n" + '</td><td id="userId' + i + '" value="' + val['companyId'] + '" >' + val['companyId'] + "\n" + '</td><td>' + val['companyName'] + "\n" + '</td><td>' + val['email'] + "\n" + '</td><td>' + val['email'] + "\n" + '</td><td>'+ "<a href = '/nisginternalcustomer?companyId=" + val['companyId'] + "&email=" + val['email'] + "'  class='bo'> Details</a> <div class='clearfix'></div></td></tr>";
				$('#myUserTable').append(table)

			}
		}
	});
	$(".tablemanager").tablemanager({
        firstSort: [[3,0],[2,0],[1,'asc']],
        disable: ["last"],
        appendFilterby: true,
        debug: true,
        vocabulary: {
            voc_filter_by: "Filter By",
            voc_type_here_filter: "Filter...",
            voc_show_rows: "Rows Per Page",
        },
        pagination: true,
        showrows: [5,10,20,50,100],
    })	
}	


	